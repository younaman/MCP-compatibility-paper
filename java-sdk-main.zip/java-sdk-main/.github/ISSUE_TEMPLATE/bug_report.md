---
name: Bug report
about: Create a bug report to help us improve the project
title: ''
labels: 'type: bug, status: waiting-for-triage'
assignees: ''

---

Please do a quick search on GitHub issues first, there might be already a duplicate issue for the one you are about to create.
If the bug is trivial, just go ahead and create the issue. Otherwise, please take a few moments and fill in the following sections:

**Bug description**
A clear and concise description of what the bug is about.

**Environment**
Please provide as many details as possible: Spring MCP version, Java version, which vector store you use if any, etc

**Steps to reproduce**
Steps to reproduce the issue.

**Expected behavior**
A clear and concise description of what you expected to happen.

**Minimal Complete Reproducible example**
Please provide a failing test or a minimal complete verifiable example that reproduces the issue.
Bug reports that are reproducible will take priority in resolution over reports that are not reproducible.
